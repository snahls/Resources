export interface IProduct {
    id: string,
    image: string,
    name: string,
}
